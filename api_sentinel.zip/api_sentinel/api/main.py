"""
API Sentinel — FastAPI Backend
All REST endpoints for scanning, results, ML training, and predictions.
"""
import uuid, json, sqlite3, sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from datetime import datetime

from scanner.scanner import APIScanner, init_db, check_security_headers, check_rate_limiting
from ml.detector   import train_models, predict_vulnerability, get_feature_importance

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "scan_results.db")

app = FastAPI(title="API Sentinel", version="1.0.0",
              description="AI-Powered API Vulnerability Detection System")

app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_methods=["*"], allow_headers=["*"])

init_db()

# ── Models ────────────────────────────────────────────────────────────────────
class EndpointConfig(BaseModel):
    path:   str
    method: str = "GET"
    params: List[str] = ["id","q","search","name"]

class ScanRequest(BaseModel):
    target_url: str
    endpoints:  List[EndpointConfig]
    headers:    Optional[Dict[str,str]] = None
    delay:      float = 0.05

# ── Scan state ────────────────────────────────────────────────────────────────
active_scans: Dict[str, str] = {}

def _run_scan(scan_id, target_url, endpoints, headers, delay):
    active_scans[scan_id] = "running"
    try:
        scanner = APIScanner(
            base_url=target_url,
            endpoints=[e.dict() for e in endpoints],
            scan_id=scan_id, headers=headers or {}, delay=delay
        )
        scanner.run_full_scan()
        active_scans[scan_id] = "completed"
    except Exception as e:
        active_scans[scan_id] = f"error: {e}"

# ── Routes ────────────────────────────────────────────────────────────────────
@app.get("/")
def root():
    return {"name":"API Sentinel","version":"1.0.0","docs":"/docs"}

@app.post("/api/scan/start")
def start_scan(req: ScanRequest, bg: BackgroundTasks):
    scan_id = str(uuid.uuid4())[:8]
    active_scans[scan_id] = "queued"
    bg.add_task(_run_scan, scan_id, req.target_url, req.endpoints,
                req.headers, req.delay)
    return {"scan_id": scan_id, "status": "started",
            "message": f"Scan {scan_id} launched against {req.target_url}"}

@app.get("/api/scan/status/{scan_id}")
def scan_status(scan_id: str):
    conn = sqlite3.connect(DB_PATH)
    row  = conn.execute("SELECT * FROM scan_sessions WHERE scan_id=?",
                        (scan_id,)).fetchone()
    conn.close()
    if row:
        cols = ["id","scan_id","target_url","start_time","end_time",
                "total_requests","total_findings","risk_score","status"]
        return dict(zip(cols, row))
    return {"scan_id": scan_id, "status": active_scans.get(scan_id, "not_found")}

@app.get("/api/results/{scan_id}")
def get_results(scan_id: str, severity: str = None,
                payload_type: str = None, limit: int = 300):
    conn   = sqlite3.connect(DB_PATH)
    q      = "SELECT * FROM scans WHERE scan_id=?"
    params = [scan_id]
    if severity:
        q += " AND severity=?"; params.append(severity)
    if payload_type:
        q += " AND payload_type=?"; params.append(payload_type)
    q += f" LIMIT {limit}"
    rows = conn.execute(q, params).fetchall()
    cols = ["id","scan_id","endpoint","method","payload","payload_type",
            "status_code","response_time","response_length","response_body",
            "response_headers","findings","severity","timestamp"]
    conn.close()
    results = [dict(zip(cols,r)) for r in rows]
    for r in results:
        try: r["findings"] = json.loads(r["findings"])
        except: r["findings"] = []
    return {"scan_id": scan_id, "count": len(results), "results": results}

@app.get("/api/results/{scan_id}/findings")
def findings_only(scan_id: str):
    conn = sqlite3.connect(DB_PATH)
    rows = conn.execute(
        "SELECT * FROM scans WHERE scan_id=? AND severity != 'none'", (scan_id,)
    ).fetchall()
    cols = ["id","scan_id","endpoint","method","payload","payload_type",
            "status_code","response_time","response_length","response_body",
            "response_headers","findings","severity","timestamp"]
    conn.close()
    results = [dict(zip(cols,r)) for r in rows]
    for r in results:
        try: r["findings"] = json.loads(r["findings"])
        except: r["findings"] = []
    # Deduplicate by endpoint+type
    seen, uniq = set(), []
    for r in results:
        k = f"{r['endpoint']}:{r['payload_type']}:{r['severity']}"
        if k not in seen:
            seen.add(k); uniq.append(r)
    return {"scan_id": scan_id, "total_vulnerabilities": len(uniq),
            "vulnerabilities": uniq}

@app.get("/api/sessions")
def list_sessions():
    conn = sqlite3.connect(DB_PATH)
    rows = conn.execute(
        "SELECT * FROM scan_sessions ORDER BY start_time DESC LIMIT 50"
    ).fetchall()
    cols = ["id","scan_id","target_url","start_time","end_time",
            "total_requests","total_findings","risk_score","status"]
    conn.close()
    return {"sessions": [dict(zip(cols,r)) for r in rows]}

@app.get("/api/stats/{scan_id}")
def get_stats(scan_id: str):
    conn = sqlite3.connect(DB_PATH)
    sev_rows = conn.execute(
        "SELECT severity,COUNT(*) FROM scans WHERE scan_id=? GROUP BY severity",
        (scan_id,)).fetchall()
    type_rows = conn.execute(
        "SELECT payload_type,COUNT(*) FROM scans WHERE scan_id=? AND severity!='none' GROUP BY payload_type",
        (scan_id,)).fetchall()
    ep_rows = conn.execute(
        "SELECT endpoint,COUNT(*) as c FROM scans WHERE scan_id=? AND severity!='none' GROUP BY endpoint ORDER BY c DESC LIMIT 10",
        (scan_id,)).fetchall()
    session = conn.execute(
        "SELECT * FROM scan_sessions WHERE scan_id=?", (scan_id,)).fetchone()
    conn.close()
    sess_cols = ["id","scan_id","target_url","start_time","end_time",
                 "total_requests","total_findings","risk_score","status"]
    return {
        "scan_id":    scan_id,
        "session":    dict(zip(sess_cols, session)) if session else {},
        "by_severity": {r[0]: r[1] for r in sev_rows},
        "by_type":     {r[0]: r[1] for r in type_rows},
        "top_vulnerable_endpoints": [{"endpoint": r[0], "count": r[1]} for r in ep_rows],
    }

@app.post("/api/train")
def train():
    try:
        metrics = train_models(verbose=False)
        return {"status": "success", "metrics": metrics}
    except Exception as e:
        raise HTTPException(500, str(e))

@app.post("/api/predict/{scan_id}")
def predict(scan_id: str):
    conn = sqlite3.connect(DB_PATH)
    rows = conn.execute("SELECT * FROM scans WHERE scan_id=?", (scan_id,)).fetchall()
    cols = ["id","scan_id","endpoint","method","payload","payload_type",
            "status_code","response_time","response_length","response_body",
            "response_headers","findings","severity","timestamp"]
    conn.close()
    data = [dict(zip(cols,r)) for r in rows]
    if not data:
        raise HTTPException(404, "No scan data found")
    preds = predict_vulnerability(data)
    vuln  = sum(1 for p in preds if p.get("final_verdict") == "VULNERABLE")
    return {"scan_id": scan_id, "total_analyzed": len(preds),
            "ai_flagged_vulnerable": vuln, "predictions": preds[:200]}

@app.get("/api/feature-importance")
def feat_importance():
    return {"features": get_feature_importance()}

@app.get("/api/headers-check")
def headers_check(url: str):
    return {"url": url, "findings": check_security_headers(url, "hdr"),
            "total": len(check_security_headers(url, "hdr"))}

@app.get("/api/rate-limit-check")
def rate_check(url: str, requests: int = 20):
    return {"url": url, "result": check_rate_limiting(url, "rl", requests)}

@app.get("/api/health")
def health():
    return {"status": "healthy", "time": datetime.now().isoformat()}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
