"""
AI/ML Detection Module
Random Forest + Decision Tree + Isolation Forest anomaly detection
"""

import sqlite3, json, os, joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from typing import List, Dict

DB_PATH   = os.path.join(os.path.dirname(__file__), "..", "data", "scan_results.db")
MODEL_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "models")


def _load_scan_data():
    try:
        conn = sqlite3.connect(DB_PATH)
        df = pd.read_sql_query("SELECT * FROM scans", conn)
        conn.close()
        return df
    except Exception:
        return pd.DataFrame()


def _engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    f = pd.DataFrame()
    f["status_code"]     = df.get("status_code",     pd.Series(dtype=int)).fillna(0).astype(int)
    f["response_time"]   = df.get("response_time",   pd.Series(dtype=float)).fillna(0).astype(float)
    f["response_length"] = df.get("response_length", pd.Series(dtype=int)).fillna(0).astype(int)
    f["payload_length"]  = df.get("payload", pd.Series(dtype=str)).fillna("").apply(len)

    specials = [("sq","'"),("lt","<"),("gt",">"),("sc",";"),
                ("pipe","|"),("amp","&"),("pt","../"),("dollar","$")]
    for name, ch in specials:
        f[f"has_{name}"] = df.get("payload", pd.Series(dtype=str)).fillna("").apply(lambda p: int(ch in p))

    pt_map = {"sqli":0,"xss":1,"cmdi":2,"ssrf":3,"path_traversal":4,"broken_auth":5}
    f["payload_type_enc"] = df.get("payload_type", pd.Series(dtype=str)).map(pt_map).fillna(6).astype(int)
    f["method_enc"]       = df.get("method", pd.Series(dtype=str)).map({"GET":0,"POST":1,"PUT":2,"DELETE":3}).fillna(0)

    body = df.get("response_body", pd.Series(dtype=str)).fillna("").str.lower()
    f["body_has_error"]    = body.apply(lambda b: int(any(e in b for e in ["error","exception","syntax","warning"])))
    f["body_has_sql"]      = body.apply(lambda b: int(any(e in b for e in ["sql","mysql","sqlite","ora-"])))
    f["body_has_script"]   = body.apply(lambda b: int("<script" in b))
    f["body_has_passwd"]   = body.apply(lambda b: int("root:x:" in b or "etc/passwd" in b))
    f["body_has_metadata"] = body.apply(lambda b: int("ami-id" in b or "instance-id" in b))
    f["is_500"]            = (f["status_code"] >= 500).astype(int)
    f["is_200"]            = (f["status_code"] == 200).astype(int)
    f["slow_response"]     = (f["response_time"] > 4.0).astype(int)
    return f


def _derive_labels(df):
    return df.get("severity", pd.Series(dtype=str)).apply(
        lambda s: 1 if s in ["critical","high","medium"] else 0
    )


def _synthetic_data():
    """Generate labelled training rows when real scan data is sparse."""
    rows = []
    # Vulnerable samples
    vuln_samples = [
        ("sqli","'","mysql error: sql syntax near",500,0.1,"critical"),
        ("sqli","1 UNION SELECT null--","column count doesn't match",500,0.1,"critical"),
        ("xss","<script>alert(1)</script>","<html><script>alert(1)</script></html>",200,0.1,"high"),
        ("xss","<img src=x onerror=alert(1)>","<img src=x onerror=alert(1)>",200,0.1,"high"),
        ("cmdi","; cat /etc/passwd","root:x:0:0:root:/root:/bin/bash",200,5.5,"critical"),
        ("cmdi","| whoami","root:x:0:0",200,5.2,"critical"),
        ("ssrf","http://169.254.169.254","ami-id: ami-0abc1234",200,0.5,"high"),
        ("ssrf","http://localhost","internal page",200,0.3,"high"),
        ("path_traversal","../etc/passwd","root:x:0:0",200,0.2,"high"),
        ("broken_auth",'{"username":"admin","password":"admin"}','{"token":"xxx","welcome":"admin"}',200,0.1,"critical"),
    ]
    for pt, pl, body, sc, rt, sev in vuln_samples * 5:
        rows.append({"payload_type":pt,"payload":pl,"response_body":body,
                     "status_code":sc,"response_time":rt,"response_length":len(body),
                     "method":"GET","severity":sev})
    # Safe samples
    safe_payloads = ["hello","world","test123","normalinput","1234","user@test.com","john"]
    for pl in safe_payloads * 8:
        for pt in ["sqli","xss","cmdi","ssrf"]:
            rows.append({"payload_type":pt,"payload":pl,"response_body":"OK",
                         "status_code":200,"response_time":0.1,"response_length":2,
                         "method":"GET","severity":"none"})
    return pd.DataFrame(rows)


def train_models(verbose=True):
    os.makedirs(MODEL_DIR, exist_ok=True)
    df = _load_scan_data()
    if len(df) < 20:
        if verbose: print("[INFO] Using synthetic training data")
        df = _synthetic_data()

    X = _engineer_features(df)
    y = _derive_labels(df)

    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)
    joblib.dump(scaler,           os.path.join(MODEL_DIR, "scaler.pkl"))
    joblib.dump(list(X.columns),  os.path.join(MODEL_DIR, "feature_names.pkl"))

    results = {}

    if len(y.unique()) > 1:
        Xtr, Xte, ytr, yte = train_test_split(Xs, y, test_size=0.2,
                                               random_state=42, stratify=y)
        # Random Forest
        rf = RandomForestClassifier(n_estimators=100, max_depth=10,
                                    random_state=42, class_weight="balanced")
        rf.fit(Xtr, ytr)
        acc_rf = accuracy_score(yte, rf.predict(Xte))
        joblib.dump(rf, os.path.join(MODEL_DIR, "random_forest.pkl"))
        results["random_forest"] = {"accuracy": round(acc_rf*100,2)}
        if verbose: print(f"[RF]  Accuracy: {acc_rf*100:.1f}%")

        # Decision Tree
        dt = DecisionTreeClassifier(max_depth=8, random_state=42, class_weight="balanced")
        dt.fit(Xtr, ytr)
        acc_dt = accuracy_score(yte, dt.predict(Xte))
        joblib.dump(dt, os.path.join(MODEL_DIR, "decision_tree.pkl"))
        results["decision_tree"] = {"accuracy": round(acc_dt*100,2)}
        if verbose: print(f"[DT]  Accuracy: {acc_dt*100:.1f}%")

    # Isolation Forest (unsupervised)
    iso = IsolationForest(n_estimators=100, contamination=0.15, random_state=42)
    iso.fit(Xs)
    joblib.dump(iso, os.path.join(MODEL_DIR, "isolation_forest.pkl"))
    results["isolation_forest"] = {"status": "trained", "samples": len(Xs)}
    if verbose: print(f"[IF]  Trained on {len(Xs)} samples")

    return results


def predict_vulnerability(scan_data: List[Dict]) -> List[Dict]:
    try:
        scaler        = joblib.load(os.path.join(MODEL_DIR, "scaler.pkl"))
        feature_names = joblib.load(os.path.join(MODEL_DIR, "feature_names.pkl"))
        rf            = joblib.load(os.path.join(MODEL_DIR, "random_forest.pkl"))
        iso           = joblib.load(os.path.join(MODEL_DIR, "isolation_forest.pkl"))
    except FileNotFoundError:
        return [{"error": "Models not trained. POST /api/train first."}]

    df = pd.DataFrame(scan_data)
    X  = _engineer_features(df)
    for col in feature_names:
        if col not in X.columns: X[col] = 0
    X  = X[feature_names]
    Xs = scaler.transform(X)

    rf_preds  = rf.predict(Xs)
    rf_proba  = rf.predict_proba(Xs)
    iso_preds = iso.predict(Xs)
    iso_scores= iso.decision_function(Xs)

    out = []
    for i, row in enumerate(scan_data):
        is_anomaly   = iso_preds[i] == -1
        is_vuln      = bool(rf_preds[i] == 1) or is_anomaly
        out.append({
            "endpoint":         row.get("endpoint",""),
            "payload_type":     row.get("payload_type",""),
            "payload":          str(row.get("payload",""))[:80],
            "rf_prediction":    "vulnerable" if rf_preds[i] == 1 else "safe",
            "rf_confidence":    round(float(max(rf_proba[i]))*100, 1),
            "isolation_forest": "anomaly" if is_anomaly else "normal",
            "anomaly_score":    round(float(iso_scores[i]), 4),
            "final_verdict":    "VULNERABLE" if is_vuln else "SAFE",
        })
    return out


def get_feature_importance() -> List[Dict]:
    try:
        rf    = joblib.load(os.path.join(MODEL_DIR, "random_forest.pkl"))
        names = joblib.load(os.path.join(MODEL_DIR, "feature_names.pkl"))
        pairs = sorted(zip(names, rf.feature_importances_), key=lambda x: x[1], reverse=True)
        return [{"feature": f, "importance": round(float(i), 4)} for f,i in pairs[:15]]
    except Exception:
        return []
