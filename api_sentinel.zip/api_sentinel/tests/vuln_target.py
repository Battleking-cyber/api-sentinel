"""
VulnTarget - Intentionally Vulnerable Practice API
*** LOCAL TESTING ONLY — NEVER DEPLOY TO PRODUCTION ***
Run this first, then scan it with API Sentinel.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse

app = FastAPI(title="VulnTarget (Local Test Only)")

USERS = [
    {"id": 1, "username": "admin",  "password": "admin",    "role": "admin"},
    {"id": 2, "username": "alice",  "password": "alice456", "role": "user"},
    {"id": 3, "username": "bob",    "password": "bob789",   "role": "user"},
]


@app.get("/")
def root():
    return {"name": "VulnTarget", "warning": "FOR LOCAL TESTING ONLY",
            "endpoints": ["/api/users","/api/search","/api/login",
                          "/api/file","/api/fetch","/api/ping","/api/echo"]}


# SQLi Vulnerable
@app.get("/api/users")
def users(id: str = "1"):
    sqli_signs = ["'","union","select","drop","or 1","or '1'","sleep","waitfor"]
    if any(s in id.lower() for s in sqli_signs):
        return JSONResponse(status_code=500, content={
            "error": f"You have an error in your SQL syntax near '{id}' at line 1 "
                     f"— mysql_fetch_array() expects parameter 1 to be resource"
        })
    try:
        uid  = int(id)
        user = next((u for u in USERS if u["id"] == uid), None)
        return {"user": {"id": user["id"], "username": user["username"],
                          "role": user["role"]}} if user else {"user": None}
    except ValueError:
        return JSONResponse(status_code=400, content={"error": "Invalid ID"})


# XSS Vulnerable — reflects input directly into HTML
@app.get("/api/search", response_class=HTMLResponse)
def search(q: str = ""):
    return f"<html><body><h2>Search: {q}</h2><p>No results.</p></body></html>"


# XSS Echo
@app.get("/api/echo", response_class=HTMLResponse)
def echo(input: str = "", q: str = "", name: str = ""):
    val = input or q or name
    return f"<html><body><p>Echo: {val}</p></body></html>"


# Broken Authentication — no rate limit, weak creds
@app.post("/api/login")
async def login(request: Request):
    try:
        body = await request.json()
    except Exception:
        return JSONResponse(status_code=400, content={"error": "Invalid JSON"})
    username = body.get("username","")
    password = body.get("password","")
    user = next((u for u in USERS
                 if u["username"] == username and u["password"] == password), None)
    if user:
        return {"success": True, "token": "eyJhbGciOiJub25lIn0.eyJ1c2VyIjoiYWRtaW4ifQ.",
                "message": f"Welcome {username}!", "role": user["role"],
                "dashboard": "/admin/dashboard"}
    return JSONResponse(status_code=401, content={"error": "Invalid credentials"})


# Command Injection Vulnerable
@app.get("/api/ping")
def ping(host: str = "localhost", cmd: str = "", exec: str = ""):
    val = host or cmd or exec
    for sign in [";","&&","||","|","&","`","$(","\n","%0a"]:
        if sign in val:
            return HTMLResponse(
                content=f"PING {val} (127.0.0.1)\n"
                        f"root:x:0:0:root:/root:/bin/bash\n"
                        f"uid=0(root) gid=0(root) groups=0(root)\n",
                status_code=200
            )
    return {"output": f"PING {val}: 64 bytes from 127.0.0.1 time=0.1ms"}


# Path Traversal Vulnerable
@app.get("/api/file")
def get_file(path: str = "readme.txt", file: str = "", dir: str = "", page: str = ""):
    val = path or file or dir or page
    traversal = ["../","..\\","%2e%2e","....//","%252e"]
    if any(t in val.lower() for t in traversal):
        return HTMLResponse(
            content="root:x:0:0:root:/root:/bin/bash\n"
                    "daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin\n"
                    "bin:x:2:2:bin:/bin:/usr/sbin/nologin",
            status_code=200
        )
    return {"filename": val, "content": "Safe file content here."}


# SSRF Vulnerable
@app.get("/api/fetch")
def fetch(url: str = "", uri: str = "", src: str = "", redirect: str = ""):
    val = url or uri or src or redirect
    for internal in ["169.254","localhost","127.0.0.1","0.0.0.0","192.168","10.0"]:
        if internal in val:
            return {"fetched": val,
                    "response": "ami-id: ami-0abc1234\n"
                                "instance-id: i-1234567890abcdef0\n"
                                "local-ipv4: 172.31.0.1",
                    "warning": "Internal metadata exposed!"}
    return {"fetched": val, "response": "OK"}


# Expose tech headers (intentionally insecure)
@app.middleware("http")
async def insecure_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Powered-By"] = "PHP/7.2.0"
    response.headers["Server"]       = "Apache/2.4.29"
    return response


if __name__ == "__main__":
    import uvicorn
    print("⚠️  VulnTarget running on http://127.0.0.1:9000  (LOCAL ONLY)")
    uvicorn.run("vuln_target:app", host="127.0.0.1", port=9000, reload=False)
