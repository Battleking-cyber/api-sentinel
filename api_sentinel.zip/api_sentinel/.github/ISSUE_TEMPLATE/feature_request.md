---
name: Feature Request
about: Suggest a new vulnerability check or feature
title: '[FEATURE] '
labels: enhancement
---

## Feature description
What vulnerability or feature would you like added?

## Why is it useful?
How does it improve the scanner?

## Example payload or implementation idea
```python
# Optional: show a code sketch
```
