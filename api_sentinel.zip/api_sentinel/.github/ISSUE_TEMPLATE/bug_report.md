---
name: Bug Report
about: Report a bug or unexpected behavior
title: '[BUG] '
labels: bug
---

## Describe the bug
A clear description of what the bug is.

## Steps to reproduce
1. Run `python run_scan.py --target ...`
2. See error

## Expected behavior
What you expected to happen.

## Environment
- OS: [e.g. Kali Linux 2024, Windows 11]
- Python version: [e.g. 3.11]
- Error message (paste here):

```
paste error here
```
