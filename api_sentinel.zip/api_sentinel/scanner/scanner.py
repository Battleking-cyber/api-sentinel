"""
API Scanner Engine
Sends crafted HTTP requests and collects responses for vulnerability analysis.
"""

import requests
import time
import json
import sqlite3
import os
from datetime import datetime
from urllib.parse import urljoin
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, asdict

from .payloads import (
    SQLI_PAYLOADS, XSS_PAYLOADS, CMDI_PAYLOADS,
    SSRF_PAYLOADS, PATH_TRAVERSAL_PAYLOADS,
    BROKEN_AUTH_PAYLOADS, SQL_ERROR_SIGNATURES
)

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "scan_results.db")


@dataclass
class ScanResult:
    scan_id: str
    endpoint: str
    method: str
    payload: str
    payload_type: str
    status_code: int
    response_time: float
    response_length: int
    response_body: str
    response_headers: str
    findings: str
    severity: str
    timestamp: str


def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_id TEXT, endpoint TEXT, method TEXT,
            payload TEXT, payload_type TEXT,
            status_code INTEGER, response_time REAL,
            response_length INTEGER, response_body TEXT,
            response_headers TEXT, findings TEXT,
            severity TEXT, timestamp TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS scan_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_id TEXT UNIQUE, target_url TEXT,
            start_time TEXT, end_time TEXT,
            total_requests INTEGER, total_findings INTEGER,
            risk_score REAL, status TEXT
        )
    """)
    conn.commit()
    conn.close()


def save_result(result: ScanResult):
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        INSERT INTO scans
          (scan_id,endpoint,method,payload,payload_type,status_code,
           response_time,response_length,response_body,response_headers,
           findings,severity,timestamp)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, (
        result.scan_id, result.endpoint, result.method, result.payload,
        result.payload_type, result.status_code, result.response_time,
        result.response_length, result.response_body[:2000],
        result.response_headers, result.findings, result.severity,
        result.timestamp
    ))
    conn.commit()
    conn.close()


def analyze_response(payload, payload_type, status, body, headers, elapsed):
    findings = []
    body_lower = body.lower()

    if payload_type == "sqli":
        for err in SQL_ERROR_SIGNATURES:
            if err in body_lower:
                findings.append(f"SQL Injection — DB error leaked: '{err}'")
                break
        if status == 500 and ("sql" in body_lower or "database" in body_lower):
            findings.append("SQL Injection — 500 error with DB context")
        if elapsed > 4.5 and "sleep" in payload.lower():
            findings.append(f"Blind SQL Injection — time delay {elapsed:.1f}s")

    elif payload_type == "xss":
        if payload in body:
            findings.append("XSS — payload reflected unescaped in response")
        if "<script>" in body_lower and "alert" in body_lower:
            findings.append("XSS — script tag reflected in HTML body")

    elif payload_type == "cmdi":
        for sign in ["root:x:", "daemon:", "bin/bash", "uid=", "gid="]:
            if sign in body_lower:
                findings.append(f"Command Injection — OS output: '{sign}'")
                break
        if elapsed > 4.0 and "sleep" in payload:
            findings.append(f"Blind Command Injection — time delay {elapsed:.1f}s")

    elif payload_type == "ssrf":
        for sign in ["ami-id", "instance-id", "169.254", "metadata", "internal"]:
            if sign in body_lower:
                findings.append(f"SSRF — internal resource accessed: '{sign}'")
                break
        if status == 200 and any(p in payload for p in ["169.254", "localhost", "127.0.0.1"]):
            findings.append("SSRF — server fetched internal/metadata URL")

    elif payload_type == "path_traversal":
        for sign in ["root:x:", "daemon:", "/bin/", "[boot loader]", "etc/hosts"]:
            if sign in body_lower:
                findings.append(f"Path Traversal — file content exposed: '{sign}'")
                break

    elif payload_type == "broken_auth":
        if status in [200, 302] and any(k in body_lower for k in
                                         ["token", "welcome", "dashboard", "logged", "success"]):
            findings.append("Broken Authentication — default credentials accepted")

    # Info disclosure for any type
    if status == 500:
        for sign in ["traceback", "exception", "stack trace", "at line"]:
            if sign in body_lower:
                findings.append("Information Disclosure — stack trace in response")
                break

    # Severity
    if not findings:
        severity = "none"
    elif payload_type in ["sqli", "cmdi", "broken_auth"]:
        severity = "critical"
    elif payload_type in ["ssrf", "path_traversal", "xss"]:
        severity = "high"
    else:
        severity = "medium"

    return findings, severity


def check_security_headers(url, scan_id):
    results = []
    try:
        resp = requests.get(url, timeout=10, verify=False)
        h = dict(resp.headers)
        required = {
            "X-Frame-Options":        "Clickjacking protection missing",
            "X-Content-Type-Options": "MIME sniffing protection missing",
            "Strict-Transport-Security": "HSTS not set",
            "Content-Security-Policy":   "CSP missing — XSS risk",
        }
        leaking = ["X-Powered-By", "Server", "X-AspNet-Version", "X-Generator"]
        for hdr, msg in required.items():
            if hdr not in h:
                results.append({"header": hdr, "finding": msg, "severity": "medium"})
        for hdr in leaking:
            if hdr in h:
                results.append({"header": hdr,
                                 "finding": f"Tech info exposed: {h[hdr]}",
                                 "severity": "low"})
        if h.get("Access-Control-Allow-Origin") == "*":
            results.append({"header": "CORS",
                             "finding": "Wildcard CORS allows any origin",
                             "severity": "high"})
    except Exception:
        pass
    return results


def check_rate_limiting(url, scan_id, num_requests=25):
    try:
        for i in range(num_requests):
            r = requests.get(url, timeout=5, verify=False)
            if r.status_code == 429:
                return {"rate_limited": True, "requests_before_block": i + 1}
    except Exception:
        pass
    return {"rate_limited": False, "requests_sent": num_requests,
            "finding": f"No rate limit after {num_requests} requests",
            "severity": "medium"}


class APIScanner:
    def __init__(self, base_url, endpoints, scan_id,
                 headers=None, timeout=10, delay=0.05):
        self.base_url = base_url.rstrip("/")
        self.endpoints = endpoints
        self.scan_id = scan_id
        self.headers = headers or {
            "Content-Type": "application/json",
            "User-Agent": "APISentinel/1.0"
        }
        self.timeout = timeout
        self.delay = delay
        self.session = requests.Session()
        self.session.headers.update(self.headers)
        self.session.verify = False
        self.results: List[ScanResult] = []
        self.total_findings = 0
        init_db()

    def _send(self, url, method, payload, payload_type,
              param_name="id", post_data=None):
        try:
            start = time.time()
            if method.upper() == "GET":
                resp = self.session.get(url, params={param_name: payload},
                                        timeout=self.timeout)
            else:
                data = post_data or {param_name: payload}
                resp = self.session.post(url, json=data, timeout=self.timeout)
            elapsed = time.time() - start

            findings, severity = analyze_response(
                payload, payload_type, resp.status_code,
                resp.text, dict(resp.headers), elapsed
            )
            result = ScanResult(
                scan_id=self.scan_id, endpoint=url,
                method=method.upper(), payload=payload,
                payload_type=payload_type, status_code=resp.status_code,
                response_time=round(elapsed, 3),
                response_length=len(resp.text),
                response_body=resp.text[:2000],
                response_headers=json.dumps(dict(resp.headers)),
                findings=json.dumps(findings), severity=severity,
                timestamp=datetime.now().isoformat()
            )
            save_result(result)
            if findings:
                self.total_findings += len(findings)
            return result
        except Exception:
            return None

    def _scan_with_payloads(self, ep, payloads, ptype):
        url = urljoin(self.base_url, ep["path"])
        results = []
        params = ep.get("params", ["id", "q", "search", "input"])
        for param in params:
            for payload in payloads:
                r = self._send(url, ep.get("method", "GET"),
                               payload, ptype, param_name=param)
                if r:
                    results.append(r)
                time.sleep(self.delay)
        return results

    def scan_sqli(self, ep):
        return self._scan_with_payloads(ep, SQLI_PAYLOADS, "sqli")

    def scan_xss(self, ep):
        return self._scan_with_payloads(ep, XSS_PAYLOADS, "xss")

    def scan_cmdi(self, ep):
        return self._scan_with_payloads(ep, CMDI_PAYLOADS, "cmdi")

    def scan_ssrf(self, ep):
        url = urljoin(self.base_url, ep["path"])
        results = []
        params = ep.get("params", ["url", "uri", "src", "redirect"])
        for param in params:
            for payload in SSRF_PAYLOADS:
                r = self._send(url, ep.get("method", "GET"),
                               payload, "ssrf", param_name=param)
                if r:
                    results.append(r)
                time.sleep(self.delay)
        return results

    def scan_path_traversal(self, ep):
        url = urljoin(self.base_url, ep["path"])
        results = []
        params = ep.get("params", ["file", "path", "dir", "page"])
        for param in params:
            for payload in PATH_TRAVERSAL_PAYLOADS:
                r = self._send(url, ep.get("method", "GET"),
                               payload, "path_traversal", param_name=param)
                if r:
                    results.append(r)
                time.sleep(self.delay)
        return results

    def scan_broken_auth(self, ep):
        url = urljoin(self.base_url, ep["path"])
        results = []
        for creds in BROKEN_AUTH_PAYLOADS:
            r = self._send(url, "POST", json.dumps(creds),
                           "broken_auth", post_data=creds)
            if r:
                results.append(r)
            time.sleep(self.delay)
        return results

    def calculate_risk_score(self):
        weights = {"critical": 25, "high": 15, "medium": 8, "low": 3, "none": 0}
        total = sum(weights.get(r.severity, 0) for r in self.results)
        return min(100.0, total)

    def run_full_scan(self, progress_callback=None):
        start_time = datetime.now()
        all_results = []
        scan_types = [
            ("SQL Injection",  self.scan_sqli),
            ("XSS",            self.scan_xss),
            ("Cmd Injection",  self.scan_cmdi),
            ("SSRF",           self.scan_ssrf),
            ("Path Traversal", self.scan_path_traversal),
        ]
        for ep in self.endpoints:
            if progress_callback:
                progress_callback(f"Scanning {ep['path']}")
            if any(k in ep["path"].lower() for k in ["login","auth","signin","token"]):
                all_results.extend(self.scan_broken_auth(ep))
            for name, fn in scan_types:
                all_results.extend(fn(ep))

        self.results = all_results
        risk_score = self.calculate_risk_score()

        conn = sqlite3.connect(DB_PATH)
        conn.execute("""
            INSERT OR REPLACE INTO scan_sessions
              (scan_id,target_url,start_time,end_time,total_requests,
               total_findings,risk_score,status)
            VALUES (?,?,?,?,?,?,?,?)
        """, (self.scan_id, self.base_url, start_time.isoformat(),
              datetime.now().isoformat(), len(all_results),
              self.total_findings, risk_score, "completed"))
        conn.commit()
        conn.close()

        return {
            "scan_id": self.scan_id,
            "target": self.base_url,
            "total_requests": len(all_results),
            "total_findings": self.total_findings,
            "risk_score": risk_score,
            "results": [asdict(r) for r in all_results]
        }
