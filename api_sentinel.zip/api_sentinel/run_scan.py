"""
run_scan.py — CLI Scanner
Usage:
    python run_scan.py                         # scan default vuln target
    python run_scan.py --target http://...     # custom target
    python run_scan.py --train-ml              # also train ML models
"""
import argparse, json, uuid, sys, os, time
from datetime import datetime

sys.path.insert(0, os.path.dirname(__file__))

from rich.console import Console
from rich.table   import Table
from rich.panel   import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich import box

from scanner.scanner import APIScanner, init_db, check_security_headers, check_rate_limiting
from ml.detector     import train_models, predict_vulnerability

console = Console()

DEFAULT_ENDPOINTS = [
    {"path":"/api/users",  "method":"GET",  "params":["id","user","name","search"]},
    {"path":"/api/search", "method":"GET",  "params":["q","query","search","input"]},
    {"path":"/api/login",  "method":"POST", "params":["username","password"]},
    {"path":"/api/file",   "method":"GET",  "params":["path","file","dir","page"]},
    {"path":"/api/fetch",  "method":"GET",  "params":["url","uri","src","redirect"]},
    {"path":"/api/ping",   "method":"GET",  "params":["host","cmd","exec"]},
    {"path":"/api/echo",   "method":"GET",  "params":["input","q","name","comment"]},
]

SEV_COLOR = {"critical":"red","high":"orange1","medium":"yellow","low":"green","none":"dim"}


def banner():
    console.print(Panel.fit(
        "[bold cyan]API SENTINEL v1.0[/bold cyan]\n"
        "[dim]AI-Powered API Vulnerability Detection System[/dim]",
        border_style="cyan"
    ))


def run(target, endpoints, scan_id, delay):
    init_db()
    scanner = APIScanner(base_url=target, endpoints=endpoints,
                         scan_id=scan_id, delay=delay)
    scan_types = [
        ("SQL Injection",  scanner.scan_sqli),
        ("XSS",            scanner.scan_xss),
        ("Cmd Injection",  scanner.scan_cmdi),
        ("SSRF",           scanner.scan_ssrf),
        ("Path Traversal", scanner.scan_path_traversal),
    ]
    total  = len(endpoints) * len(scan_types)
    step   = 0
    all_results = []

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
                  BarColumn(), TextColumn("[cyan]{task.completed}/{task.total}"),
                  console=console) as progress:
        task = progress.add_task("Scanning...", total=total)
        for ep in endpoints:
            if any(k in ep["path"].lower() for k in ["login","auth","signin"]):
                all_results.extend(scanner.scan_broken_auth(ep))
            for name, fn in scan_types:
                progress.update(task,
                    description=f"[cyan]{name}[/] ➜ {ep['path']}")
                all_results.extend(fn(ep))
                step += 1
                progress.update(task, completed=step)

    scanner.results = all_results
    risk = scanner.calculate_risk_score()

    import sqlite3
    from scanner.scanner import DB_PATH
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        INSERT OR REPLACE INTO scan_sessions
          (scan_id,target_url,start_time,end_time,
           total_requests,total_findings,risk_score,status)
        VALUES (?,?,?,?,?,?,?,?)
    """, (scan_id, target, datetime.now().isoformat(),
          datetime.now().isoformat(), len(all_results),
          scanner.total_findings, risk, "completed"))
    conn.commit(); conn.close()

    return {"scan_id":scan_id,"target":target,
            "total_requests":len(all_results),
            "total_findings":scanner.total_findings,
            "risk_score":risk, "results":all_results}


def print_table(results):
    vulns = [r for r in results
             if r.severity not in ["none",""]
             and json.loads(r.findings if isinstance(r.findings,str) else "[]")]
    if not vulns:
        console.print("\n[bold green]✓ No vulnerabilities found.[/]"); return

    t = Table(title=f"Vulnerabilities ({len(vulns)})", box=box.ROUNDED, show_lines=True)
    t.add_column("Severity", width=10)
    t.add_column("Type",     width=16)
    t.add_column("Endpoint", width=28)
    t.add_column("Payload",  width=32, overflow="fold")
    t.add_column("Finding",  width=38, overflow="fold")

    for r in vulns[:60]:
        fs  = json.loads(r.findings) if isinstance(r.findings,str) else r.findings
        col = SEV_COLOR.get(r.severity,"white")
        ep  = "/".join(r.endpoint.split("/")[-2:]) if "/" in r.endpoint else r.endpoint
        t.add_row(
            f"[{col}]{r.severity.upper()}[/{col}]",
            r.payload_type, ep,
            str(r.payload)[:40],
            str(fs[0])[:45] if fs else "—"
        )
    console.print(t)


def main():
    parser = argparse.ArgumentParser(description="API Sentinel Scanner")
    parser.add_argument("--target",   "-t", default="http://127.0.0.1:9000")
    parser.add_argument("--output",   "-o", default="scan_report.json")
    parser.add_argument("--delay",    "-d", type=float, default=0.05)
    parser.add_argument("--train-ml", action="store_true")
    args = parser.parse_args()

    banner()
    console.print(f"\n[bold]Target:[/] {args.target}")

    if args.train_ml:
        console.print("[cyan]Training ML models...[/]")
        m = train_models(verbose=False)
        console.print(f"[green]✓ Trained:[/] {list(m.keys())}")

    console.print("[cyan]Checking security headers...[/]")
    hdr = check_security_headers(args.target, "cli")
    console.print(f"{'[yellow]⚠' if hdr else '[green]✓'} "
                  f"{'%d header issue(s)' % len(hdr) if hdr else 'Headers OK'}[/]")

    scan_id = str(uuid.uuid4())[:8]
    console.print(f"\n[bold cyan]Scan ID: {scan_id}[/]\n")

    t0 = time.time()
    result = run(args.target, DEFAULT_ENDPOINTS, scan_id, args.delay)
    elapsed = time.time() - t0

    print_table(result["results"])

    score = result["risk_score"]
    col   = "red" if score>=70 else "orange1" if score>=40 else "yellow" if score>=20 else "green"
    lbl   = "CRITICAL" if score>=70 else "HIGH" if score>=40 else "MEDIUM" if score>=20 else "LOW"
    console.print(f"\n[bold]Risk Score:[/] [{col}]{score:.0f}/100 — {lbl}[/{col}]")
    console.print(f"[dim]Requests:[/] {result['total_requests']}  "
                  f"[dim]Findings:[/] {result['total_findings']}  "
                  f"[dim]Time:[/] {elapsed:.1f}s")

    # AI prediction
    try:
        data  = [{"endpoint":r.endpoint,"payload":r.payload,"payload_type":r.payload_type,
                  "status_code":r.status_code,"response_time":r.response_time,
                  "response_length":r.response_length,"response_body":r.response_body,
                  "method":r.method} for r in result["results"]]
        preds = predict_vulnerability(data)
        vuln  = sum(1 for p in preds if p.get("final_verdict")=="VULNERABLE")
        console.print(f"[bold]AI flagged:[/] [red]{vuln}[/] requests as suspicious")
    except Exception as e:
        console.print(f"[dim]AI skipped: {e}[/]")

    os.makedirs("data", exist_ok=True)
    report = {
        "scan_id": scan_id, "target": args.target,
        "duration_seconds": round(elapsed,2),
        "total_requests": result["total_requests"],
        "total_findings": result["total_findings"],
        "risk_score": result["risk_score"],
        "header_findings": hdr,
        "vulnerabilities": [
            {"endpoint":r.endpoint,"method":r.method,"payload_type":r.payload_type,
             "payload":r.payload,"status_code":r.status_code,"severity":r.severity,
             "findings": json.loads(r.findings) if isinstance(r.findings,str) else r.findings}
            for r in result["results"] if r.severity not in ["none",""]
        ]
    }
    with open(args.output,"w") as f:
        json.dump(report, f, indent=2)
    console.print(f"\n[bold green]✓ Report:[/] {args.output}\n")


if __name__ == "__main__":
    main()
